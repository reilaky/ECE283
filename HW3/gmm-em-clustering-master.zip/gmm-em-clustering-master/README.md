# gmm-em-clustering
高斯混合模型（GMM 聚类）的 EM 算法实现。

# 相关文章
[高斯混合模型 EM 算法的 Python 实现](http://www.codebelief.com/article/2017/11/gmm-em-algorithm-implementation-by-python/)

# 测试结果
![](http://ofgbgq4gz.bkt.clouddn.com/171124/gmm.png-default)
